/*
 * Ryan Phillips
 * CS 349 Project
 * UserDaoInterface.java
 */
package dao;

import java.util.List;
import java.util.Optional;

import model.User;

public interface UserDaoInterface {
    int create(User user);
    Optional<User> readOneUser(int id);
    Optional<User> readByUsername(String username);
    List<User> getAll();
    boolean delete(int id);
    boolean promoteToAdmin(int id);
}
