/*
 * Ryan Phillips
 * CS 349 Project
 * RecipeDao.java
 */

package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import model.Recipe;
import model.RecipeCategory;
import util.DbConnection;

public class RecipeDao implements RecipeDaoInterface {

    private static final String RECIPE_COLUMNS =
            "id, user_id, owner_name, name, description, category, ingredients, instructions, "
                    + "calories_per_serving, servings, prep_minutes, shareable, favorite";

    private final DbConnection connection;

    public RecipeDao(DbConnection connection) {
        this.connection = connection;
    }

    @Override
    public List<Recipe> getAll() {
        String sql = "SELECT " + RECIPE_COLUMNS + " FROM tb_recipe ORDER BY id DESC";
        List<Recipe> recipes = new ArrayList<>();

        try (Connection conn = connection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                recipes.add(mapRowToRecipe(rs));
            }

            return recipes;
        } catch (SQLException ex) {
            throw new IllegalStateException("Unable to load recipes.", ex);
        }
    }

    @Override
    public List<Recipe> getByUser(int userId) {
        String sql = "SELECT " + RECIPE_COLUMNS + " FROM tb_recipe WHERE user_id = ? ORDER BY id DESC";
        List<Recipe> recipes = new ArrayList<>();

        try (Connection conn = connection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, userId);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    recipes.add(mapRowToRecipe(rs));
                }
            }

            return recipes;
        } catch (SQLException ex) {
            throw new IllegalStateException("Unable to load user recipes.", ex);
        }
    }

    @Override
    public Recipe getById(int id) {
        String sql = "SELECT " + RECIPE_COLUMNS + " FROM tb_recipe WHERE id = ?";

        try (Connection conn = connection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRowToRecipe(rs);
                }
            }

            return null;
        } catch (SQLException ex) {
            throw new IllegalStateException("Unable to load recipe.", ex);
        }
    }

    @Override
    public Recipe getByUserIdAndRecipeId(int userId, int id) {
        String sql = "SELECT " + RECIPE_COLUMNS + " FROM tb_recipe WHERE user_id = ? AND id = ?";

        try (Connection conn = connection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, userId);
            ps.setInt(2, id);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRowToRecipe(rs);
                }
            }

            return null;
        } catch (SQLException ex) {
            throw new IllegalStateException("Unable to load recipe.", ex);
        }
    }

    @Override
    public int create(Recipe recipe) {
        String sql = "INSERT INTO tb_recipe "
                + "(user_id, owner_name, name, description, category, ingredients, instructions, "
                + "calories_per_serving, servings, prep_minutes, shareable, favorite) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = connection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setInt(1, recipe.getUserId());
            ps.setString(2, recipe.getOwnerName());
            ps.setString(3, recipe.getName());
            ps.setString(4, recipe.getDescription());
            ps.setString(5, recipe.getCategory() == null ? null : recipe.getCategory().name());
            ps.setString(6, recipe.getIngredients());
            ps.setString(7, recipe.getInstructions());
            ps.setInt(8, recipe.getCaloriesPerServing());
            ps.setInt(9, recipe.getServings());
            ps.setInt(10, recipe.getPrepMinutes());
            ps.setBoolean(11, recipe.isShareable());
            ps.setBoolean(12, recipe.isFavorite());

            int rows = ps.executeUpdate();
            if (rows == 0) {
                throw new IllegalStateException("Recipe insert failed.");
            }

            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    return keys.getInt(1);
                }
            }

            throw new IllegalStateException("Recipe insert failed: no ID returned.");
        } catch (SQLException ex) {
            throw new IllegalStateException("Unable to save recipe.", ex);
        }
    }

    @Override
    public boolean update(Recipe recipe) {
        String sql = "UPDATE tb_recipe SET "
                + "owner_name = ?, name = ?, description = ?, category = ?, ingredients = ?, "
                + "instructions = ?, calories_per_serving = ?, servings = ?, prep_minutes = ?, "
                + "shareable = ?, favorite = ? "
                + "WHERE id = ? AND user_id = ?";

        try (Connection conn = connection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, recipe.getOwnerName());
            ps.setString(2, recipe.getName());
            ps.setString(3, recipe.getDescription());
            ps.setString(4, recipe.getCategory() == null ? null : recipe.getCategory().name());
            ps.setString(5, recipe.getIngredients());
            ps.setString(6, recipe.getInstructions());
            ps.setInt(7, recipe.getCaloriesPerServing());
            ps.setInt(8, recipe.getServings());
            ps.setInt(9, recipe.getPrepMinutes());
            ps.setBoolean(10, recipe.isShareable());
            ps.setBoolean(11, recipe.isFavorite());
            ps.setInt(12, recipe.getId());
            ps.setInt(13, recipe.getUserId());

            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            throw new IllegalStateException("Unable to update recipe.", ex);
        }
    }

    @Override
    public boolean delete(int userId, int id) {
        String sql = "DELETE FROM tb_recipe WHERE user_id = ? AND id = ?";

        try (Connection conn = connection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, userId);
            ps.setInt(2, id);

            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            throw new IllegalStateException("Unable to delete recipe.", ex);
        }
    }
    
    @Override
    public boolean deleteById(int id) {
        String sql = "DELETE FROM tb_recipe WHERE id = ?";

        try (Connection conn = connection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            throw new IllegalStateException("Unable to delete recipe.", ex);
        }
    }

    @Override
    public boolean deleteByUserId(int userId) {
        String sql = "DELETE FROM tb_recipe WHERE user_id = ?";

        try (Connection conn = connection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, userId);
            ps.executeUpdate();
            return true;
        } catch (SQLException ex) {
            throw new IllegalStateException("Unable to delete user recipes.", ex);
        }
    }

    private Recipe mapRowToRecipe(ResultSet rs) throws SQLException {
        String categoryValue = rs.getString("category");

        RecipeCategory category = (categoryValue == null || categoryValue.isBlank())
                ? null
                : RecipeCategory.valueOf(categoryValue);

        return new Recipe(
                rs.getInt("id"),
                rs.getInt("user_id"),
                rs.getString("owner_name"),
                rs.getString("name"),
                rs.getString("description"),
                category,
                rs.getString("ingredients"),
                rs.getString("instructions"),
                rs.getInt("calories_per_serving"),
                rs.getInt("servings"),
                rs.getInt("prep_minutes"),
                rs.getBoolean("shareable"),
                rs.getBoolean("favorite")
        );
    }
}