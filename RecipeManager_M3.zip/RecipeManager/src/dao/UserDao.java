/*
 * Ryan Phillips
 * CS 349 Project
 * UserDao.java
 */
package dao;

import java.util.ArrayList;
import java.util.List;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.Optional;

import model.User;
import util.DbConnection;

// Crud Operation for users,  used for login, registration, and admin stuff
public class UserDao implements UserDaoInterface {
    private static final String USER_COLUMNS =
            "id, username, fullname, email, password_hash, admin, created_at";

    private final DbConnection connection;

    public UserDao(DbConnection connection) {
        this.connection = connection;
    }

    private User mapRowToUser(ResultSet rs) throws SQLException {
        Timestamp createdAt = rs.getTimestamp("created_at");
        return new User(
                rs.getInt("id"),
                rs.getString("username"),
                rs.getString("fullname"),
                rs.getString("email"),
                rs.getString("password_hash"),
                createdAt == null ? null : createdAt.toLocalDateTime(),
                rs.getBoolean("admin"));
    }
    
    
    @Override
    public int create(User user) {
        String query = "INSERT INTO tb_user (username, fullname, email, password_hash, admin) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = connection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, user.getUsername());
            ps.setString(2, user.getFullName());
            ps.setString(3, user.getEmail());
            ps.setString(4, user.getPasswordHash());
            ps.setBoolean(5, user.getIsAdmin());

            int rows = ps.executeUpdate();
            if (rows == 0) {
                throw new IllegalStateException("User insert failed: no rows were affected.");
            }

            try (ResultSet generatedKeys = ps.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    return generatedKeys.getInt(1);
                }
            }

            throw new IllegalStateException("User insert failed: generated ID was not returned.");
        } catch (SQLException ex) {
            throw new IllegalStateException("Unable to save user details.", ex);
        }
    }
    
    @Override
    public Optional<User> readOneUser(int id) {
        String query = "SELECT " + USER_COLUMNS + " FROM tb_user WHERE id = ?";

        try (Connection conn = connection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapRowToUser(rs));
                }
            }

            return Optional.empty();
        } catch (SQLException ex) {
            throw new IllegalStateException("Unable to read user by ID.", ex);
        }
    }
    
    @Override
    public Optional<User> readByUsername(String username) {
        String query = "SELECT " + USER_COLUMNS + " FROM tb_user WHERE LOWER(username) = LOWER(?)";

        try (Connection conn = connection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setString(1, username);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapRowToUser(rs));
                }
            }

            return Optional.empty();
        } catch (SQLException ex) {
            throw new IllegalStateException("Unable to read user by username.", ex);
        }
    }
    
    @Override
    public List<User> getAll() {
        String query = "SELECT " + USER_COLUMNS + " FROM tb_user ORDER BY username ASC";
        List<User> users = new ArrayList<>();

        try (Connection conn = connection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                users.add(mapRowToUser(rs));
            }

            return users;
        } catch (SQLException ex) {
            throw new IllegalStateException("Unable to load users.", ex);
        }
    }
    
    
    // Since recipes have a user_id as a foreign key with cascade on delete they will automatically be deleted with user
    @Override
    public boolean delete(int id) {
        String query = "DELETE FROM tb_user WHERE id = ?";

        try (Connection conn = connection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            throw new IllegalStateException("Unable to delete user.", ex);
        }
    }

    @Override
    public boolean promoteToAdmin(int id) {
        String query = "UPDATE tb_user SET admin = true WHERE id = ?";

        try (Connection conn = connection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            throw new IllegalStateException("Unable to promote user.", ex);
        }
    }
}
