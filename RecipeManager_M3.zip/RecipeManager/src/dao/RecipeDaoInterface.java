/*
 * Ryan Phillips
 * CS 349 Project
 * RecipeDAOInterface.java
 */

package dao;

import java.util.List;
import java.util.Optional;

import model.Recipe;

public interface RecipeDaoInterface {
    List<Recipe> getAll();
    List<Recipe> getByUser(int userId);
    Recipe getById(int id);
    Recipe getByUserIdAndRecipeId(int userId, int id);
    int create(Recipe recipe);
    boolean update(Recipe recipe);
    boolean delete(int userId, int id);
    
    boolean deleteById(int id);
    boolean deleteByUserId(int userId);
}
