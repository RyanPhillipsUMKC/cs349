/*
 * Ryan Phillips
 * CS 349 Project
 * RecipeDialog.java
 */

package view;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import model.Recipe;
import model.RecipeCategory;
import model.User;

// The Dilog used for creation and editing recipes 
// uses constructor recipe parameter for editing an existing recipe
public class RecipeDialog extends JDialog {
	private static final long serialVersionUID = 1L;
	
    private final User user;

    private final JTextField txtName = new JTextField(24);
    private final JTextField txtDescription = new JTextField(60);
    private final JComboBox<RecipeCategory> cmbCategory = new JComboBox<>(RecipeCategory.values());
    private final JTextField txtCalories = new JTextField(10);
    private final JTextField txtServings = new JTextField(10);
    private final JTextField txtPrepMinutes = new JTextField(10);
    private final JCheckBox chkShareable = new JCheckBox("Recipe can be viewed by others");
    private final JCheckBox chkFavorite = new JCheckBox("Favorite recipe");
    private final JTextArea txtIngredients = new JTextArea(6, 24);
    private final JTextArea txtInstructions = new JTextArea(8, 24);

    private boolean confirmed;
    private int recipeId;

    public RecipeDialog(Frame owner, String title, Recipe recipe, User user) {
        super(owner, title, true);
        this.user = user;
        buildUi();
        populate(recipe);
        pack();
        setLocationRelativeTo(owner);
    }

    private void buildUi() {
        setLayout(new BorderLayout(10, 10));

        JPanel formPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 6, 6, 6);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // add all text fields
        int row = 0;
        addRow(formPanel, gbc, row++, "Name", txtName);
        addRow(formPanel, gbc, row++, "Description", txtDescription);
        addRow(formPanel, gbc, row++, "Category", cmbCategory);
        addRow(formPanel, gbc, row++, "Calories / serving", txtCalories);
        addRow(formPanel, gbc, row++, "Servings", txtServings);
        addRow(formPanel, gbc, row++, "Prep minutes", txtPrepMinutes);
        addRow(formPanel, gbc, row++, "Sharing", chkShareable);
        addRow(formPanel, gbc, row++, "Favorite", chkFavorite);
        
        
        //Handle ingredient and instruction text area differently because not normal text field
        // plus we want to allow scrolling
        txtIngredients.setLineWrap(true);
        txtIngredients.setWrapStyleWord(true);
        txtInstructions.setLineWrap(true);
        txtInstructions.setWrapStyleWord(true);

        gbc.gridx = 0;
        gbc.gridy = row;
        gbc.weightx = 0;
        gbc.weighty = 0;
        gbc.anchor = GridBagConstraints.NORTHWEST;
        formPanel.add(new JLabel("Ingredients"), gbc);

        gbc.gridx = 1;
        gbc.weightx = 1;
        formPanel.add(new JScrollPane(txtIngredients), gbc);
        row++;

        gbc.gridx = 0;
        gbc.gridy = row;
        gbc.weightx = 0;
        formPanel.add(new JLabel("Instructions"), gbc);

        gbc.gridx = 1;
        gbc.weightx = 1;
        formPanel.add(new JScrollPane(txtInstructions), gbc);

        // actions for buttons
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton btnOk = new JButton("OK");
        JButton btnCancel = new JButton("Cancel");
        btnOk.addActionListener(e -> {
            confirmed = true;
            setVisible(false);
        });
        btnCancel.addActionListener(e -> {
            confirmed = false;
            setVisible(false);
        });
        buttonPanel.add(btnOk);
        buttonPanel.add(btnCancel);

        add(formPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }
    
    // adds row to the panel this function is just to make sure we have consistent styling
    private void addRow(JPanel panel, GridBagConstraints gbc, int row, String label, java.awt.Component component) {
        gbc.gridx = 0;
        gbc.gridy = row;
        gbc.weightx = 0;
        gbc.weighty = 0;
        gbc.anchor = GridBagConstraints.WEST;
        panel.add(new JLabel(label), gbc);

        gbc.gridx = 1;
        gbc.weightx = 1;
        panel.add(component, gbc);
    }

    private void populate(Recipe recipe) {
        if (recipe == null) {
            recipeId = 0;
            cmbCategory.setSelectedItem(RecipeCategory.BREAKFAST);
            return;
        }
        
        // a recipe was passed in constructor so we populate fields from that
        // most likely for the edit window
        recipeId = recipe.getId();
        txtName.setText(recipe.getName());
        txtDescription.setText(recipe.getDescription());
        cmbCategory.setSelectedItem(recipe.getCategory());
        txtCalories.setText(String.valueOf(recipe.getCaloriesPerServing()));
        txtServings.setText(String.valueOf(recipe.getServings()));
        txtPrepMinutes.setText(String.valueOf(recipe.getPrepMinutes()));
        chkShareable.setSelected(recipe.isShareable());
        chkFavorite.setSelected(recipe.isFavorite());
        txtIngredients.setText(recipe.getIngredients());
        txtInstructions.setText(recipe.getInstructions());
    }

    public boolean isConfirmed() {
        return confirmed;
    }
    
    // allocate and return new or edited recipe
    public Recipe getRecipe() {
        Recipe recipe = new Recipe();
        recipe.setId(recipeId);
        recipe.setUserId(user.getId());
        recipe.setOwnerName(user.getUsername());
        recipe.setName(txtName.getText().trim());
        recipe.setDescription(txtDescription.getText().trim());
        recipe.setCategory((RecipeCategory) cmbCategory.getSelectedItem());
        recipe.setIngredients(txtIngredients.getText().trim());
        recipe.setInstructions(txtInstructions.getText().trim());
        recipe.setCaloriesPerServing(Integer.parseInt(txtCalories.getText().trim()));
        recipe.setServings(Integer.parseInt(txtServings.getText().trim()));
        recipe.setPrepMinutes(Integer.parseInt(txtPrepMinutes.getText().trim()));
        recipe.setShareable(chkShareable.isSelected());
        recipe.setFavorite(chkFavorite.isSelected());
        return recipe;
    }
}