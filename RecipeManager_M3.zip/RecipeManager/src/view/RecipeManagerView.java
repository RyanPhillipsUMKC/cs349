/*
 * Ryan Phillips
 * CS 349 Project
 * RecipeManagerView.java
 */

package view;

import java.awt.BorderLayout;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;

import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;
import javax.swing.JCheckBox;

import controller.RecipeController;
import model.Recipe;
import model.User;
import service.RecipeServiceInterface;
import service.UserServiceInterface;

// Main app view
public class RecipeManagerView extends JFrame {
	private static final long serialVersionUID = 1L;
	
	JButton btnRefresh = new JButton("Refresh/List All");
    JButton btnAsyncRefresh = new JButton("Async Refresh/List All");
    JButton btnNew = new JButton("New/Create");
    JButton btnEdit = new JButton("Edit/Update");
    JButton btnDelete = new JButton("Delete");
    JButton btnSearch = new JButton("Search");
    JButton btnClearSearch = new JButton("Clear Search");
    // Logout button (bottom right)
    JButton btnLogout = new JButton("Logout");
    private final JTextField txtSearchName = new JTextField(14);
    private final JTextField txtSearchIngredient = new JTextField(14);
    private final JTextField txtSearchMinCalories = new JTextField(6);
    private final JTextField txtSearchMaxCalories = new JTextField(6);
    private final JCheckBox chkSearchSharedRecipes = new JCheckBox("Include shared recipes");
    private final JLabel lblStatus = new JLabel("Ready.");
    

    private final DefaultTableModel tableModel = new DefaultTableModel(
            new Object[]{"ID", "Name", "Description", "Category", "Calories", "Servings", "Prep", "Ingredients", "Shareable", "Favorite"}, 0) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };

    private final JTable tblRecipes = new JTable(tableModel);
    private final RecipeController controller;

    public RecipeManagerView(User user, UserServiceInterface userService, RecipeServiceInterface recipeService) {
        super("Recipe Manager");
        this.controller = new RecipeController(user, userService, recipeService, this);
        buildUi();
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(1280, 620));
        setLocationRelativeTo(null);
        controller.loadAllRecipes();
    }

    private void buildUi() {
        setLayout(new BorderLayout(10, 10));
        ((JPanel) getContentPane()).setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));

        JLabel header = new JLabel("Recipe Manager", SwingConstants.LEFT);
        header.setFont(header.getFont().deriveFont(Font.BOLD, 22f));
        add(header, BorderLayout.NORTH);

        add(buildCenterPanel(), BorderLayout.CENTER);
        add(buildFooter(), BorderLayout.SOUTH);
    }

    private JPanel buildCenterPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.add(buildToolbar(), BorderLayout.NORTH);

        tblRecipes.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tblRecipes.setRowHeight(24);
        JScrollPane scrollPane = new JScrollPane(tblRecipes);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Recipes"));
        panel.add(scrollPane, BorderLayout.CENTER);

        return panel;
    }

    private JPanel buildToolbar() {
        JPanel wrapper = new JPanel(new BorderLayout(8, 8));

        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 6));
        searchPanel.setBorder(BorderFactory.createTitledBorder("Search / Filter"));
        searchPanel.add(new JLabel("Name"));
        searchPanel.add(txtSearchName);
        searchPanel.add(new JLabel("Ingredient"));
        searchPanel.add(txtSearchIngredient);
        searchPanel.add(new JLabel("Min Calories"));
        searchPanel.add(txtSearchMinCalories);
        searchPanel.add(new JLabel("Max Calories"));
        searchPanel.add(txtSearchMaxCalories);
        searchPanel.add(chkSearchSharedRecipes);
        
        btnSearch.addActionListener(e -> controller.searchRecipes());
        btnClearSearch.addActionListener(e -> controller.clearSearch());
        searchPanel.add(btnSearch);
        searchPanel.add(btnClearSearch);

        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        
        btnRefresh.addActionListener(e -> controller.loadAllRecipes());
        btnAsyncRefresh.addActionListener(e -> controller.loadAllRecipesAsync());
        btnNew.addActionListener(e -> controller.openCreateDialog());
        btnEdit.addActionListener(e -> controller.openEditDialog());
        btnDelete.addActionListener(e -> controller.deleteSelectedRecipe());

        actionPanel.add(btnRefresh);
        actionPanel.add(btnAsyncRefresh);
        actionPanel.add(btnNew);
        actionPanel.add(btnEdit);
        actionPanel.add(btnDelete);

        wrapper.add(searchPanel, BorderLayout.NORTH);
        wrapper.add(actionPanel, BorderLayout.SOUTH);
        return wrapper;
    }
    
    
    // status and logout
    private JPanel buildFooter() {
        JPanel footer = new JPanel(new BorderLayout());
        lblStatus.setBorder(BorderFactory.createEmptyBorder(4, 8, 4, 8));
        footer.add(lblStatus, BorderLayout.CENTER);
        
        btnLogout.addActionListener(e -> controller.onLogoutButtonClick());

        JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        rightPanel.add(btnLogout);

        footer.add(rightPanel, BorderLayout.EAST);
        return footer;
    }

    
    // populate recipe table with human readable info
    public void setRecipes(List<Recipe> recipes) {
        tableModel.setRowCount(0);
        for (Recipe recipe : recipes) {
            tableModel.addRow(new Object[]{
                    recipe.getId(),
                    recipe.getName(),
                    recipe.getDescription(),
                    recipe.getCategory(),
                    recipe.getCaloriesPerServing(),
                    recipe.getServings(),
                    recipe.getPrepMinutes(),
                    recipe.getIngredients(),
                    recipe.isShareable() ? "Yes" : "No",
                    recipe.isFavorite() ? "Yes" : "No"
            });
        }
    }
    
    // return id of current selected/ highlighed recipe
    public int getSelectedRecipeId() {
        int row = tblRecipes.getSelectedRow();
        if (row < 0) {
            return -1;
        }
        //
        return Integer.parseInt(tableModel.getValueAt(row, 0).toString());
    }

    public void selectRecipeById(int recipeId) {
        for (int row = 0; row < tableModel.getRowCount(); row++) {
            long id = Long.parseLong(tableModel.getValueAt(row, 0).toString());
            if (id == recipeId) {
                tblRecipes.setRowSelectionInterval(row, row);
                tblRecipes.scrollRectToVisible(tblRecipes.getCellRect(row, 0, true));
                return;
            }
        }
        tblRecipes.clearSelection();
    }

    public String getSearchNameTerm() {
        return txtSearchName.getText().trim();
    }

    public String getSearchIngredientTerm() {
        return txtSearchIngredient.getText().trim();
    }

    public Integer getSearchMinCalories() {
        return parseOptionalInteger(txtSearchMinCalories.getText().trim());
    }

    public Integer getSearchMaxCalories() {
        return parseOptionalInteger(txtSearchMaxCalories.getText().trim());
    }

    public void clearSearchFields() {
        txtSearchName.setText("");
        txtSearchIngredient.setText("");
        txtSearchMinCalories.setText("");
        txtSearchMaxCalories.setText("");
        chkSearchSharedRecipes.setSelected(false);
    }

    public void showStatus(String message) {
        lblStatus.setText(message);
    }

    private Integer parseOptionalInteger(String value) {
        return value == null || value.isBlank() ? null : Integer.parseInt(value);
    }
    
    public boolean shouldSearchSharedRecipes() {
        return chkSearchSharedRecipes.isSelected();
    }
    
    /**
     * Enables or disables only recipe controls during async loading.
     * The recipe table is intentionally left enabled so it can still be clicked.
     *
     * @param busy true while recipes are loading
     * @param statusMessage message shown in the footer
     */
    public void setBusy(boolean busy, String statusMessage) {
        txtSearchName.setEnabled(!busy);
        txtSearchIngredient.setEnabled(!busy);
        txtSearchMinCalories.setEnabled(!busy);
        txtSearchMaxCalories.setEnabled(!busy);
        chkSearchSharedRecipes.setEnabled(!busy);

        btnSearch.setEnabled(!busy);
        btnClearSearch.setEnabled(!busy);
        btnRefresh.setEnabled(!busy);
        btnAsyncRefresh.setEnabled(!busy);
        btnNew.setEnabled(!busy);
        btnEdit.setEnabled(!busy);
        btnDelete.setEnabled(!busy);
        btnLogout.setEnabled(!busy);

        setCursor(busy
                ? Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR)
                : Cursor.getDefaultCursor());

        lblStatus.setText(statusMessage);
    }
}
