/*
 * Ryan Phillips
 * CS 349 Project
 * AdminController.java
 */
package view;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

import controller.AdminController;
import model.Recipe;
import model.User;
import service.RecipeServiceInterface;
import service.UserServiceInterface;


// Mimics the normal recipe CRUD, and search but always searchs globally
// Also, allow for user search and CRUD operation on users
public class AdminView extends JFrame {
	private static final long serialVersionUID = 1L;
	
    private final JTextField txtUserSearch = new JTextField(18);

    private final JTextField txtRecipeNameSearch = new JTextField(14);
    private final JTextField txtRecipeOwnerSearch = new JTextField(14);
    private final JTextField txtRecipeIngredientSearch = new JTextField(14);

    private final JLabel lblStatus = new JLabel("Ready.");

    private final DefaultTableModel userTableModel = new DefaultTableModel(
            new Object[]{"ID", "Username", "Full Name", "Email", "Admin"}, 0) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };

    private final DefaultTableModel recipeTableModel = new DefaultTableModel(
            new Object[]{"ID", "User ID", "Owner", "Name", "Category", "Calories", "Shareable", "Favorite"}, 0) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };

    private final JTable tblUsers = new JTable(userTableModel);
    private final JTable tblRecipes = new JTable(recipeTableModel);

    private final AdminController controller;

    public AdminView(User adminUser, UserServiceInterface userService, RecipeServiceInterface recipeService) {
        super("Recipe Manager - Admin");
        this.controller = new AdminController(adminUser, userService, recipeService, this);

        buildUi();

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(1180, 700));
        setLocationRelativeTo(null);

        controller.loadAllData();
    }

    private void buildUi() {
        setLayout(new BorderLayout(10, 10));
        ((JPanel) getContentPane()).setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));

        JLabel header = new JLabel("Admin Manager", SwingConstants.LEFT);
        header.setFont(header.getFont().deriveFont(Font.BOLD, 22f));
        add(header, BorderLayout.NORTH);

        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, buildUserPanel(), buildRecipePanel());
        splitPane.setResizeWeight(0.45);
        add(splitPane, BorderLayout.CENTER);

        add(buildFooter(), BorderLayout.SOUTH);
    }

    private JPanel buildUserPanel() {
        JPanel panel = new JPanel(new BorderLayout(8, 8));
        panel.setBorder(BorderFactory.createTitledBorder("Users"));

        JPanel toolbar = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 6));
        toolbar.add(new JLabel("Search Users"));
        toolbar.add(txtUserSearch);

        JButton btnSearch = new JButton("Search");
        JButton btnClear = new JButton("Clear");
        JButton btnDelete = new JButton("Delete User");
        JButton btnPromote = new JButton("Promote To Admin");

        btnSearch.addActionListener(e -> controller.loadUsers());
        btnClear.addActionListener(e -> controller.clearUserSearch());
        btnDelete.addActionListener(e -> controller.deleteSelectedUser());
        btnPromote.addActionListener(e -> controller.promoteSelectedUser());

        toolbar.add(btnSearch);
        toolbar.add(btnClear);
        toolbar.add(btnDelete);
        toolbar.add(btnPromote);

        tblUsers.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tblUsers.setRowHeight(24);

        panel.add(toolbar, BorderLayout.NORTH);
        panel.add(new JScrollPane(tblUsers), BorderLayout.CENTER);

        return panel;
    }

    private JPanel buildRecipePanel() {
        JPanel panel = new JPanel(new BorderLayout(8, 8));
        panel.setBorder(BorderFactory.createTitledBorder("Recipes"));

        JPanel toolbar = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 6));
        toolbar.add(new JLabel("Name"));
        toolbar.add(txtRecipeNameSearch);
        toolbar.add(new JLabel("Owner"));
        toolbar.add(txtRecipeOwnerSearch);
        toolbar.add(new JLabel("Ingredient"));
        toolbar.add(txtRecipeIngredientSearch);

        JButton btnSearch = new JButton("Search");
        JButton btnClear = new JButton("Clear");
        JButton btnDelete = new JButton("Delete Recipe");

        btnSearch.addActionListener(e -> controller.loadRecipes());
        btnClear.addActionListener(e -> controller.clearRecipeSearch());
        btnDelete.addActionListener(e -> controller.deleteSelectedRecipe());

        toolbar.add(btnSearch);
        toolbar.add(btnClear);
        toolbar.add(btnDelete);

        tblRecipes.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tblRecipes.setRowHeight(24);

        panel.add(toolbar, BorderLayout.NORTH);
        panel.add(new JScrollPane(tblRecipes), BorderLayout.CENTER);

        return panel;
    }

    private JPanel buildFooter() {
        JPanel footer = new JPanel(new BorderLayout());
        lblStatus.setBorder(BorderFactory.createEmptyBorder(4, 8, 4, 8));
        footer.add(lblStatus, BorderLayout.CENTER);

        JButton btnLogout = new JButton("Logout");
        btnLogout.addActionListener(e -> controller.onLogoutButtonClick());

        JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        rightPanel.add(btnLogout);

        footer.add(rightPanel, BorderLayout.EAST);
        return footer;
    }

    public void setUsers(List<User> users) {
        userTableModel.setRowCount(0);

        for (User user : users) {
            userTableModel.addRow(new Object[]{
                    user.getId(),
                    user.getUsername(),
                    user.getFullName(),
                    user.getEmail(),
                    user.getIsAdmin() ? "Yes" : "No"
            });
        }
    }

    public void setRecipes(List<Recipe> recipes) {
        recipeTableModel.setRowCount(0);

        for (Recipe recipe : recipes) {
            recipeTableModel.addRow(new Object[]{
                    recipe.getId(),
                    recipe.getUserId(),
                    recipe.getOwnerName(),
                    recipe.getName(),
                    recipe.getCategory(),
                    recipe.getCaloriesPerServing(),
                    recipe.isShareable() ? "Yes" : "No",
                    recipe.isFavorite() ? "Yes" : "No"
            });
        }
    }

    public int getSelectedUserId() {
        int row = tblUsers.getSelectedRow();
        if (row < 0) {
            return -1;
        }

        return Integer.parseInt(userTableModel.getValueAt(row, 0).toString());
    }

    public int getSelectedRecipeId() {
        int row = tblRecipes.getSelectedRow();
        if (row < 0) {
            return -1;
        }

        return Integer.parseInt(recipeTableModel.getValueAt(row, 0).toString());
    }

    public String getUserSearchTerm() {
        return txtUserSearch.getText().trim();
    }

    public String getRecipeNameSearchTerm() {
        return txtRecipeNameSearch.getText().trim();
    }

    public String getRecipeOwnerSearchTerm() {
        return txtRecipeOwnerSearch.getText().trim();
    }

    public String getRecipeIngredientSearchTerm() {
        return txtRecipeIngredientSearch.getText().trim();
    }

    public void clearUserSearch() {
        txtUserSearch.setText("");
    }

    public void clearRecipeSearch() {
        txtRecipeNameSearch.setText("");
        txtRecipeOwnerSearch.setText("");
        txtRecipeIngredientSearch.setText("");
    }

    public void showStatus(String message) {
        lblStatus.setText(message);
    }
}