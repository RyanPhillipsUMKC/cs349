/*
 * Ryan Phillips
 * CS 349 Project
 * UserService.java
 */
package service;

import java.util.Optional;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import dao.UserDaoInterface;
import model.User;
import util.PasswordHasher;

// Business logic for registration and authentication.

public class UserService implements UserServiceInterface {
    private final UserDaoInterface userDao;
    private final PasswordHasher passwordHasher;

    public UserService(UserDaoInterface userDao, PasswordHasher passwordHasher) {
        this.userDao = userDao;
        this.passwordHasher = passwordHasher;
    }
    
    @Override
    public User registerUser(String username, String fullName, String email, String plainPassword) {
        String normalizedUsername = normalizeRequired(username, "Username");
        String normalizedFullName = normalizeRequired(fullName, "Full name");
        String normalizedEmail = normalizeRequired(email, "Email");
        String normalizedPassword = normalizeRequired(plainPassword, "Password");

        Optional<User> existingUser = userDao.readByUsername(normalizedUsername);
        if (existingUser.isPresent()) {
            throw new IllegalArgumentException("That username is already taken.");
        }

        User newUser = new User();
        newUser.setUsername(normalizedUsername);
        newUser.setFullName(normalizedFullName);
        newUser.setEmail(normalizedEmail);
        newUser.setPasswordHash(passwordHasher.hash(normalizedPassword));
        newUser.setIsAdmin(false);

        int id = userDao.create(newUser);
        newUser.setId(id);
        return newUser;
    }
    
    @Override
    public User login(String username, String plainPassword) {
        String normalizedUsername = normalizeRequired(username, "Username");
        String normalizedPassword = normalizeRequired(plainPassword, "Password");

        Optional<User> user = userDao.readByUsername(normalizedUsername);
        if (user.isEmpty()) {
            return null;
        }

        String storedHash = user.get().getPasswordHash();
        if (passwordHasher.matches(normalizedPassword, storedHash == null ? null : storedHash.trim())) {
            return user.get();
        }
        return null;
    }
    
    @Override
    public List<User> searchUsers(String searchTerm) {
        List<User> users = userDao.getAll();
        List<User> filtered = new ArrayList<>();

        String normalizedSearch = normalize(searchTerm);

        for (User user : users) {
            boolean matchesSearch = normalizedSearch.isEmpty()
                    || normalize(user.getUsername()).contains(normalizedSearch)
                    || normalize(user.getFullName()).contains(normalizedSearch)
                    || normalize(user.getEmail()).contains(normalizedSearch);

            if (matchesSearch) {
                filtered.add(user);
            }
        }

        filtered.sort(Comparator.comparing(User::getUsername, String.CASE_INSENSITIVE_ORDER));
        return filtered;
    }

    @Override
    public void promoteUserToAdmin(int id) {
        if (id <= 0) {
            throw new IllegalArgumentException("User id must be valid.");
        }

        User user = userDao.readOneUser(id)
                .orElseThrow(() -> new IllegalArgumentException("User with id " + id + " was not found."));

        if (user.getIsAdmin()) {
            throw new IllegalArgumentException("User is already an admin.");
        }

        boolean promoted = userDao.promoteToAdmin(id);
        if (!promoted) {
            throw new IllegalArgumentException("User with id " + id + " was not promoted.");
        }
    }

    @Override
    public void deleteUser(int id) {
        if (id <= 0) {
            throw new IllegalArgumentException("User id must be valid.");
        }

        userDao.readOneUser(id)
                .orElseThrow(() -> new IllegalArgumentException("User with id " + id + " was not found."));
        
        // dont need to manually delete recipes for user
        // sql cascade delete handles this automatically
        //recipeDao.deleteByUserId(id);

        boolean deleted = userDao.delete(id);
        if (!deleted) {
            throw new IllegalArgumentException("User with id " + id + " was not deleted.");
        }
    }

    private String normalize(String value) {
        return value == null ? "" : value.trim().toLowerCase();
    }

    private String normalizeRequired(String value, String fieldName) {
        if (value == null) {
            throw new IllegalArgumentException(fieldName + " is required.");
        }

        String trimmed = value.trim();
        if (trimmed.isEmpty()) {
            throw new IllegalArgumentException(fieldName + " is required.");
        }
        return trimmed;
    }
}
