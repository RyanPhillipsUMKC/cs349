/*
 * Ryan Phillips
 * CS 349 Project
 * UserServiceInterface.java
 */
package service;

import java.util.List;

import model.User;

public interface UserServiceInterface {
    User registerUser(String username, String fullName, String email, String plainPassword);
    User login(String username, String plainPassword);
    List<User> searchUsers(String searchTerm);
    void promoteUserToAdmin(int id);
    void deleteUser(int id);
}