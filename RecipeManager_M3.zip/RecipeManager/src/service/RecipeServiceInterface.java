/*
 * Ryan Phillips
 * CS 349 Project
 * RecipeService.java
 */

package service;

import java.util.List;

import model.Recipe;


public interface RecipeServiceInterface {
    List<Recipe> getAllRecipes();
    List<Recipe> getAllRecipesByUserId(int userId);
    List<Recipe> searchRecipes(int userId, String nameTerm, String ingredientTerm, Integer minCalories, Integer maxCalories, boolean bCheckSharedRecipes);
    Recipe getRecipeByUserIdAndRecipeId(int userId, int id);
    Recipe createRecipe(Recipe recipe);
    Recipe updateRecipe(Recipe recipe);
    void deleteRecipe(int userId, int id);
    List<Recipe> adminSearchRecipes(String nameTerm, String ownerTerm, String ingredientTerm);
    void adminDeleteRecipe(int id);
}
