/*
 * Ryan Phillips
 * CS 349 Project
 * RecipeService.java
 */

package service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import dao.RecipeDaoInterface;
import model.Recipe;
import model.RecipeCategory;

// This service implementation validates business logic and if something fails that validation it throws an
// IllegalArgumentException that can bubble up and be handled by the controller

public class RecipeService implements RecipeServiceInterface {
    private final RecipeDaoInterface recipeDao;

    public RecipeService(RecipeDaoInterface recipeDao) {
        this.recipeDao = recipeDao;
    }

    // return all recipes in alphabetic order
    @Override
    public List<Recipe> getAllRecipes() {
        List<Recipe> recipes = recipeDao.getAll();
        recipes.sort(Comparator.comparing(Recipe::getName, String.CASE_INSENSITIVE_ORDER));
        return recipes;
    }

    // return all recipes for one user in alphabetic order
    @Override
    public List<Recipe> getAllRecipesByUserId(int userId) {
        if (userId <= 0) {
            throw new IllegalArgumentException("User id must be valid.");
        }

        List<Recipe> recipes = recipeDao.getByUser(userId);
        recipes.sort(Comparator.comparing(Recipe::getName, String.CASE_INSENSITIVE_ORDER));
        return recipes;
    }

    // opt in search by field, allows user to be as specific as they want
    @Override
    public List<Recipe> searchRecipes(int userId, String nameTerm, String ingredientTerm, Integer minCalories, Integer maxCalories, boolean bCheckSharedRecipes) {
    	if (userId <= 0) {
            throw new IllegalArgumentException("User id must be valid.");
        }
        if (minCalories != null && minCalories < 0) {
            throw new IllegalArgumentException("Minimum calories cannot be negative.");
        }
        if (maxCalories != null && maxCalories < 0) {
            throw new IllegalArgumentException("Maximum calories cannot be negative.");
        }
        if (minCalories != null && maxCalories != null && minCalories > maxCalories) {
            throw new IllegalArgumentException("Minimum calories cannot be greater than maximum calories.");
        }

        List<Recipe> filtered = new ArrayList<>();

        String normalizedName = normalize(nameTerm);
        String normalizedIngredient = normalize(ingredientTerm);

        List<Recipe> recipesToSearch = bCheckSharedRecipes
                ? getAllRecipes()
                : getAllRecipesByUserId(userId);

        for (Recipe recipe : recipesToSearch) {
            boolean isUsersRecipe = recipe.getUserId() == userId;
            boolean isOtherUsersSharedRecipe = recipe.getUserId() != userId && recipe.isShareable();

            if (!isUsersRecipe && !isOtherUsersSharedRecipe) {
                continue;
            }

            boolean matchesName = normalizedName.isEmpty()
                    || normalize(recipe.getName()).contains(normalizedName);

            boolean matchesIngredient = normalizedIngredient.isEmpty()
                    || normalize(recipe.getIngredients()).contains(normalizedIngredient);

            boolean matchesMinCalories = minCalories == null
                    || recipe.getCaloriesPerServing() >= minCalories;

            boolean matchesMaxCalories = maxCalories == null
                    || recipe.getCaloriesPerServing() <= maxCalories;

            if (matchesName && matchesIngredient && matchesMinCalories && matchesMaxCalories) {
                filtered.add(recipe);
            }
        }

        filtered.sort(Comparator.comparing(Recipe::getName, String.CASE_INSENSITIVE_ORDER));
        return filtered;
    }

    @Override
    public Recipe getRecipeByUserIdAndRecipeId(int userId, int id) {
        if (userId <= 0) {
            throw new IllegalArgumentException("User id must be valid.");
        }
        if (id <= 0) {
            throw new IllegalArgumentException("Recipe id must be valid.");
        }

        Recipe recipe = recipeDao.getByUserIdAndRecipeId(userId, id);

        if (recipe == null) {
            throw new IllegalArgumentException("Recipe with id " + id + " was not found.");
        }

        return recipe;
    }

    @Override
    public Recipe createRecipe(Recipe recipe) {
        validateRecipe(recipe, true);

        int id = recipeDao.create(recipe);

        Recipe createdRecipe = recipeDao.getById(id);
        if (createdRecipe == null) {
            throw new IllegalStateException("Recipe was created but could not be loaded.");
        }

        return createdRecipe;
    }

    @Override
    public Recipe updateRecipe(Recipe recipe) {
        validateRecipe(recipe, false);

        boolean updated = recipeDao.update(recipe);
        if (!updated) {
            throw new IllegalArgumentException("Recipe with id " + recipe.getId() + " was not found.");
        }

        Recipe updatedRecipe = recipeDao.getByUserIdAndRecipeId(recipe.getUserId(), recipe.getId());
        if (updatedRecipe == null) {
            throw new IllegalStateException("Recipe was updated but could not be loaded.");
        }

        return updatedRecipe;
    }

    @Override
    public void deleteRecipe(int userId, int id) {
        getRecipeByUserIdAndRecipeId(userId, id);

        boolean deleted = recipeDao.delete(userId, id);
        if (!deleted) {
            throw new IllegalArgumentException("Recipe with id " + id + " was not deleted.");
        }
    }
    
    @Override
    public List<Recipe> adminSearchRecipes(String nameTerm, String ownerTerm, String ingredientTerm) {
        List<Recipe> filtered = new ArrayList<>();

        String normalizedName = normalize(nameTerm);
        String normalizedOwner = normalize(ownerTerm);
        String normalizedIngredient = normalize(ingredientTerm);

        for (Recipe recipe : getAllRecipes()) {
            boolean matchesName = normalizedName.isEmpty()
                    || normalize(recipe.getName()).contains(normalizedName);

            boolean matchesOwner = normalizedOwner.isEmpty()
                    || normalize(recipe.getOwnerName()).contains(normalizedOwner);

            boolean matchesIngredient = normalizedIngredient.isEmpty()
                    || normalize(recipe.getIngredients()).contains(normalizedIngredient);

            if (matchesName && matchesOwner && matchesIngredient) {
                filtered.add(recipe);
            }
        }

        filtered.sort(Comparator.comparing(Recipe::getName, String.CASE_INSENSITIVE_ORDER));
        return filtered;
    }

    @Override
    public void adminDeleteRecipe(int id) {
        if (id <= 0) {
            throw new IllegalArgumentException("Recipe id must be valid.");
        }

        Recipe recipe = recipeDao.getById(id);
        if (recipe == null) {
            throw new IllegalArgumentException("Recipe with id " + id + " was not found.");
        }

        boolean deleted = recipeDao.deleteById(id);
        if (!deleted) {
            throw new IllegalArgumentException("Recipe with id " + id + " was not deleted.");
        }
    }

    // Business logic
    // validation checks for creation and updating
    private void validateRecipe(Recipe recipe, boolean isCreate) {
        if (recipe == null) {
            throw new IllegalArgumentException("Recipe cannot be null.");
        }
        if (recipe.getUserId() <= 0) {
            throw new IllegalArgumentException("User id is required.");
        }
        if (isBlank(recipe.getOwnerName())) {
            throw new IllegalArgumentException("Owner name is required.");
        }
        if (isBlank(recipe.getName())) {
            throw new IllegalArgumentException("Recipe name is required.");
        }
        if (recipe.getCategory() == null) {
            recipe.setCategory(RecipeCategory.OTHER);
        }
        if (isBlank(recipe.getIngredients())) {
            throw new IllegalArgumentException("Ingredients are required.");
        }
        if (isBlank(recipe.getInstructions())) {
            throw new IllegalArgumentException("Instructions are required.");
        }
        if (recipe.getCaloriesPerServing() < 0) {
            throw new IllegalArgumentException("Calories per serving must be 0 or greater.");
        }
        if (recipe.getServings() <= 0) {
            throw new IllegalArgumentException("Servings must be greater than 0.");
        }
        if (recipe.getPrepMinutes() <= 0) {
            throw new IllegalArgumentException("Preparation time must be greater than 0.");
        }
        if (!isCreate && recipe.getId() <= 0) {
            throw new IllegalArgumentException("Existing recipes must have a valid id.");
        }
    }

    private boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }

    private String normalize(String value) {
        return value == null ? "" : value.trim().toLowerCase();
    }
}