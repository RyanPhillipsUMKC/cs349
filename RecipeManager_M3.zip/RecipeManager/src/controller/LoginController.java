/*
 * Ryan Phillips
 * CS 349 Project
 * LoginController.java
 */

package controller;

import java.util.Arrays;

import javax.swing.JOptionPane;

import model.User;
import service.RecipeServiceInterface;
import service.UserServiceInterface;
import view.AdminView;
import view.LoginView;
import view.RecipeManagerView;
import view.RegisterView;

/**
 * Handles user interactions on the login screen.
 */
public class LoginController {

    private final LoginView loginView;
    private final UserServiceInterface userService;
    private final RecipeServiceInterface recipeService;

    /**
     * Creates a controller for the supplied login view.
     *
     * @param loginView login screen managed by this controller
     */
    public LoginController(LoginView loginView, UserServiceInterface userService, RecipeServiceInterface recipeService) {
        this.loginView = loginView;
        this.userService = userService;
        this.recipeService = recipeService;
    }

    /**
     * Validates login fields and opens the task list when the form looks valid.
     */
    public void onLoginButtonClick() {
        String username = loginView.getUsername();
        char[] password = loginView.getPassword();

        try {
            if (username.isBlank() || password.length == 0) {
                loginView.setStatus("Please enter both username and password.");
                return;
            }
            
            User user = userService.login(username, new String(password));
            if (user != null) {
                RecipeManagerView managerView = new RecipeManagerView(
                        user,
                        userService,
                        recipeService);
                managerView.setVisible(true);
                //managerView.start();
                loginView.dispose();
            } else {
                loginView.setStatus("Invalid username or password.");
            }
        } catch (IllegalArgumentException ex) {
            loginView.setStatus(ex.getMessage());
        } catch (RuntimeException ex) {
            showError("Unable to complete login: " + ex.getMessage(), "Login Error");
        } finally {
            Arrays.fill(password, '\0');
        }
    }

    /**
     * Opens the register screen.
     */
    public void onRegisterButtonClick() {
        RegisterView registerView = new RegisterView(userService, recipeService);
        registerView.setVisible(true);
        loginView.dispose();
    }
    
    public void onAdminLoginButtonClick() {
        String username = loginView.getUsername();
        char[] password = loginView.getPassword();

        try {
            if (username.isBlank() || password.length == 0) {
                loginView.setStatus("Please enter both username and password.");
                return;
            }

            User user = userService.login(username, new String(password));

            if (user == null) {
                loginView.setStatus("Invalid username or password.");
                return;
            }

            if (!user.getIsAdmin()) {
                loginView.setStatus("Admin login failed. This account is not an admin.");
                return;
            }

            AdminView adminView = new AdminView(user, userService, recipeService);
            adminView.setVisible(true);
            loginView.dispose();
        } catch (IllegalArgumentException ex) {
            loginView.setStatus(ex.getMessage());
        } catch (RuntimeException ex) {
            showError("Unable to complete admin login: " + ex.getMessage(), "Admin Login Error");
        } finally {
            Arrays.fill(password, '\0');
        }
    }

    private void showError(String message, String title) {
        JOptionPane.showMessageDialog(loginView, message, title, JOptionPane.ERROR_MESSAGE);
    }
}
