/*
 * Ryan Phillips
 * CS 349 Project
 * AdminController.java
 */
package controller;

import java.util.List;

import javax.swing.JOptionPane;

import model.Recipe;
import model.User;
import service.RecipeServiceInterface;
import service.UserServiceInterface;
import view.AdminView;
import view.LoginView;

// Admin controller does not have its own service to use it just reuses the recipe and user service for crud operations
public class AdminController {
    private final User adminUser;
    private final UserServiceInterface userService;
    private final RecipeServiceInterface recipeService;
    private final AdminView view;

    public AdminController(User adminUser, UserServiceInterface userService,
                           RecipeServiceInterface recipeService, AdminView view) {
        if (adminUser == null || !adminUser.getIsAdmin()) {
            throw new IllegalArgumentException("Admin access is required.");
        }

        this.adminUser = adminUser;
        this.userService = userService;
        this.recipeService = recipeService;
        this.view = view;
    }

    public void loadAllData() {
        loadUsers();
        loadRecipes();
    }

    public void loadUsers() {
        List<User> users = userService.searchUsers(view.getUserSearchTerm());
        view.setUsers(users);
        view.showStatus("Loaded " + users.size() + " user(s).");
    }

    public void loadRecipes() {
        List<Recipe> recipes = recipeService.adminSearchRecipes(
                view.getRecipeNameSearchTerm(),
                view.getRecipeOwnerSearchTerm(),
                view.getRecipeIngredientSearchTerm()
        );

        view.setRecipes(recipes);
        view.showStatus("Loaded " + recipes.size() + " recipe(s).");
    }

    public void clearUserSearch() {
        view.clearUserSearch();
        loadUsers();
    }

    public void clearRecipeSearch() {
        view.clearRecipeSearch();
        loadRecipes();
    }

    public void deleteSelectedUser() {
        int selectedUserId = view.getSelectedUserId();

        if (selectedUserId <= 0) {
            showMessage("Select a user to delete.");
            return;
        }

        if (selectedUserId == adminUser.getId()) {
            showError("You cannot delete your own admin account while logged in.");
            return;
        }

        int choice = JOptionPane.showConfirmDialog(
                view,
                "Delete the selected user and all of their recipes?",
                "Confirm Delete User",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE
        );

        if (choice != JOptionPane.YES_OPTION) {
            view.showStatus("Delete user canceled.");
            return;
        }

        try {
            userService.deleteUser(selectedUserId);
            loadAllData();
            view.showStatus("User deleted successfully.");
        } catch (IllegalArgumentException ex) {
            showError(ex.getMessage());
        }
    }

    public void promoteSelectedUser() {
        int selectedUserId = view.getSelectedUserId();

        if (selectedUserId <= 0) {
            showMessage("Select a user to promote.");
            return;
        }

        try {
            userService.promoteUserToAdmin(selectedUserId);
            loadUsers();
            view.showStatus("User promoted to admin.");
        } catch (IllegalArgumentException ex) {
            showError(ex.getMessage());
        }
    }

    public void deleteSelectedRecipe() {
        int selectedRecipeId = view.getSelectedRecipeId();

        if (selectedRecipeId <= 0) {
            showMessage("Select a recipe to delete.");
            return;
        }

        int choice = JOptionPane.showConfirmDialog(
                view,
                "Delete the selected recipe?",
                "Confirm Delete Recipe",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE
        );

        if (choice != JOptionPane.YES_OPTION) {
            view.showStatus("Delete recipe canceled.");
            return;
        }

        try {
            recipeService.adminDeleteRecipe(selectedRecipeId);
            loadRecipes();
            view.showStatus("Recipe deleted successfully.");
        } catch (IllegalArgumentException ex) {
            showError(ex.getMessage());
        }
    }

    public void onLogoutButtonClick() {
        LoginView loginView = new LoginView(userService, recipeService);
        loginView.setVisible(true);
        view.dispose();
    }

    private void showError(String message) {
        view.showStatus(message);
        JOptionPane.showMessageDialog(view, message, "Admin Error", JOptionPane.ERROR_MESSAGE);
    }

    private void showMessage(String message) {
        view.showStatus(message);
        JOptionPane.showMessageDialog(view, message, "Information", JOptionPane.INFORMATION_MESSAGE);
    }
}