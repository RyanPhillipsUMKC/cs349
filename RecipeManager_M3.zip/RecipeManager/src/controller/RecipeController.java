/*
 * Ryan Phillips
 * CS 349 Project
 * RecipeController.java
 */
package controller;

import java.util.List;

import javax.swing.JOptionPane;
import javax.swing.SwingWorker;

import model.Recipe;
import model.User;
import service.RecipeServiceInterface;
import service.UserServiceInterface;
import view.LoginView;
import view.RecipeDialog;
import view.RecipeManagerView;


public class RecipeController {
    private static final long SIMULATED_LOAD_DELAY_MS = 3000L;

    private final User user;
    private final UserServiceInterface userService;
    private final RecipeServiceInterface recipeService;
    private final RecipeManagerView view;

    private SwingWorker<List<Recipe>, Void> activeLoadWorker;

    // Pass service and view as parameters so we can dependency inject theese
    public RecipeController(User user, UserServiceInterface userService, RecipeServiceInterface recipeService, RecipeManagerView view) {
        this.user = user;
        this.userService = userService;
        this.recipeService = recipeService;
        this.view = view;
    }

    // blocking update recipe list and status message
    public void loadAllRecipes() {
        refreshTable(recipeService.getAllRecipesByUserId(user.getId()));
        view.showStatus("Loaded " + recipeService.getAllRecipesByUserId(user.getId()).size() + " recipe(s).");
    }

    // async version of refresh/list all using SwingWorker so the UI does not freeze
    public void loadAllRecipesAsync() {
	    if (activeLoadWorker != null && !activeLoadWorker.isDone()) {
	        view.showStatus("Recipes are already loading.");
	        return;
	    }

	    view.setBusy(true, "Async refresh started. Simulating a 3 second database load.");

	    activeLoadWorker = new SwingWorker<List<Recipe>, Void>() {
	        @Override
	        protected List<Recipe> doInBackground() {
	            simulateSlowDatabaseDelay();
	            return recipeService.getAllRecipesByUserId(user.getId());
	        }

	        @Override
	        protected void done() {
	            try {
	                List<Recipe> recipes = get();
	                refreshTable(recipes);
	                view.setBusy(false, "Async refresh complete. Loaded " + recipes.size() + " recipe(s).");
	            } catch (Exception ex) {
	                view.setBusy(false, "Async refresh failed.");
	                showError("Unable to load recipes: " + ex.getMessage());
	            } finally {
	                activeLoadWorker = null;
	            }
	        }
	    };

	    activeLoadWorker.execute();
    }

    // create and show recipe dialogue for creation
    // update status for cancelation, success or error
    // show error message for caught exception
    public void openCreateDialog() {
        RecipeDialog dialog = new RecipeDialog(view, "New Recipe", null, user);
        dialog.setVisible(true);

        if (!dialog.isConfirmed()) {
            view.showStatus("Create canceled.");
            return;
        }

        try {
            Recipe created = recipeService.createRecipe(dialog.getRecipe());
            refreshTable(recipeService.getAllRecipesByUserId(user.getId()));
            view.selectRecipeById(created.getId());
            view.showStatus("Recipe created successfully.");
        } catch (IllegalArgumentException exception) {
            showError(exception.getMessage());
        }
    }

    // same as creation dialog function above except
    // edit an existing entity by its id
    public void openEditDialog() {
        int selectedId = view.getSelectedRecipeId();
        if (selectedId <= 0) {
            showMessage("Select a recipe to edit.");
            return;
        }

        try {
            Recipe recipe = recipeService.getRecipeByUserIdAndRecipeId(user.getId(), selectedId);
            RecipeDialog dialog = new RecipeDialog(view, "Edit Recipe", recipe, user);
            dialog.setVisible(true);

            if (!dialog.isConfirmed()) {
                view.showStatus("Edit canceled.");
                return;
            }

            Recipe updated = recipeService.updateRecipe(dialog.getRecipe());
            refreshTable(recipeService.getAllRecipesByUserId(user.getId()));
            view.selectRecipeById(updated.getId());
            view.showStatus("Recipe updated successfully.");
        } catch (IllegalArgumentException ex) {
            showError(ex.getMessage());
        }
    }

    // delete the selected recipe by id
    // gated by confirmation dialog
    public void deleteSelectedRecipe() {
        int selectedId = view.getSelectedRecipeId();
        if (selectedId <= 0) {
            showMessage("Select a recipe to delete.");
            return;
        }

        int choice = JOptionPane.showConfirmDialog(
                view,
                "Delete the selected recipe?",
                "Confirm Delete",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE
        );

        if (choice != JOptionPane.YES_OPTION) {
            view.showStatus("Delete canceled.");
            return;
        }

        try {
            recipeService.deleteRecipe(user.getId(), selectedId);
            refreshTable(recipeService.getAllRecipesByUserId(user.getId()));
            view.showStatus("Recipe deleted successfully.");
        } catch (IllegalArgumentException ex) {
            showError(ex.getMessage());
        }
    }

    // search filter for recipes... each field is opt in
    // e.g. if max calories does not have a number it will not be accounted for
    public void searchRecipes() {
        try {
            Integer minCalories = view.getSearchMinCalories();
            Integer maxCalories = view.getSearchMaxCalories();
            List<Recipe> results = recipeService.searchRecipes(
                    user.getId(),
                    view.getSearchNameTerm(),
                    view.getSearchIngredientTerm(),
                    minCalories,
                    maxCalories,
                    view.shouldSearchSharedRecipes()
            );
            refreshTable(results);
            view.showStatus("Found " + results.size() + " matching recipe(s).");
        } catch (NumberFormatException ex) {
            showError("Calories must be whole numbers.");
        } catch (IllegalArgumentException ex) {
            showError(ex.getMessage());
        }
    }

    // clear all filters for search
    public void clearSearch() {
        view.clearSearchFields();
        loadAllRecipes();
        view.showStatus("Search cleared.");
    }

    /**
     * Returns the user to the login screen after confirmation.
     */
    public void onLogoutButtonClick() {
        int choice = JOptionPane.showConfirmDialog(view,
                "Log out now?",
                "Logout",
                JOptionPane.YES_NO_OPTION);

        if (choice == JOptionPane.YES_OPTION) {
            if (activeLoadWorker != null && !activeLoadWorker.isDone()) {
                activeLoadWorker.cancel(true);
            }

            LoginView loginView = new LoginView(userService, recipeService);
            loginView.setVisible(true);
            view.dispose();
        }
    }

    // called after each update so data is not stale in main manager view
    private void refreshTable(List<Recipe> recipes) {
        view.setRecipes(recipes);
    }

    private void simulateSlowDatabaseDelay() {
        try {
            Thread.sleep(SIMULATED_LOAD_DELAY_MS);
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException("Recipe loading was interrupted.");
        }
    }

    private void showError(String message) {
        view.showStatus(message);
        JOptionPane.showMessageDialog(view, message, "Validation Error", JOptionPane.ERROR_MESSAGE);
    }

    private void showMessage(String message) {
        view.showStatus(message);
        JOptionPane.showMessageDialog(view, message, "Information", JOptionPane.INFORMATION_MESSAGE);
    }
}
