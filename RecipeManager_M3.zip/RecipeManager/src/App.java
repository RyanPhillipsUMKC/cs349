/*
 * Ryan Phillips
 * CS 349 Project
 * App.java
 */

import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

import dao.RecipeDao;
import dao.UserDao;
import service.RecipeService;
import service.UserService;
import util.DbConfig;
import util.DbConnection;
import util.PasswordHasher;
import view.LoginView;

public class App {
	
	// Entry point start on event dispatching thread
	public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                DbConfig config = new DbConfig();
                DbConnection connection = new DbConnection(config);

                UserDao userDao = new UserDao(connection);
                RecipeDao recipeDao = new RecipeDao(connection);
                PasswordHasher passwordHasher = new PasswordHasher();

                UserService userService = new UserService(userDao, passwordHasher);
                RecipeService recipeService = new RecipeService(recipeDao);

                new LoginView(userService, recipeService).setVisible(true);
            } catch (RuntimeException ex) {
                JOptionPane.showMessageDialog(
                        null,
                        ex.getMessage(),
                        "Application Startup Error",
                        JOptionPane.ERROR_MESSAGE);
            }
        });
    }
}
