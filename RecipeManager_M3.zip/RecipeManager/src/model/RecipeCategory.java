/*
 * Ryan Phillips
 * CS 349 Project
 * RecipeCategory.java
 */

package model;

public enum RecipeCategory {
    BREAKFAST("Breakfast"),
    LUNCH("Lunch"),
    DINNER("Dinner"),
    DESSERT("Dessert"),
    SNACK("Snack"),
    DRINK("Drink"),
    OTHER("Other");

    private final String displayName;

    RecipeCategory(String displayName) {
        this.displayName = displayName;
    }

    @Override
    public String toString() {
        return displayName;
    }
}
