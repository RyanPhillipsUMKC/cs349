/*
 * Ryan Phillips
 * CS 349 Project
 * Recipe.java
 */

package model;

// will mirror databse entry to allow for loading recipes into memory
public class Recipe {
    private int id;
    private int userId;
    private String ownerName;
    private String name;
    private String description;
    private RecipeCategory category;
    private String ingredients;
    private String instructions;
    private int caloriesPerServing;
    private int servings;
    private int prepMinutes;
    private boolean shareable;
    private boolean favorite;

    public Recipe() {
    }

    public Recipe(int id, int userId, String ownerName, String name, String description, RecipeCategory category, String ingredients, String instructions,
                  int caloriesPerServing, int servings, int prepMinutes, boolean shareable, boolean favorite) {
        this.id = id;
        this.userId = userId;
        this.ownerName = ownerName;
        this.name = name;
        this.description = description;
        this.category = category;
        this.ingredients = ingredients;
        this.instructions = instructions;
        this.caloriesPerServing = caloriesPerServing;
        this.servings = servings;
        this.prepMinutes = prepMinutes;
        this.shareable = shareable;
        this.favorite = favorite;
    }

    public Recipe copy() {
        return new Recipe(
                id,
                userId,
                ownerName,
                name,
                description,
                category,
                ingredients,
                instructions,
                caloriesPerServing,
                servings,
                prepMinutes,
                shareable,
                favorite
        );
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    public int getUserId() {
        return userId;
    }

    public void setUserId(int id) {
        this.userId = id;
    }


    public String getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public RecipeCategory getCategory() {
        return category;
    }

    public void setCategory(RecipeCategory category) {
        this.category = category;
    }

    public String getIngredients() {
        return ingredients;
    }

    public void setIngredients(String ingredients) {
        this.ingredients = ingredients;
    }

    public String getInstructions() {
        return instructions;
    }

    public void setInstructions(String instructions) {
        this.instructions = instructions;
    }

    public int getCaloriesPerServing() {
        return caloriesPerServing;
    }

    public void setCaloriesPerServing(int caloriesPerServing) {
        this.caloriesPerServing = caloriesPerServing;
    }

    public int getServings() {
        return servings;
    }

    public void setServings(int servings) {
        this.servings = servings;
    }

    public int getPrepMinutes() {
        return prepMinutes;
    }

    public void setPrepMinutes(int prepMinutes) {
        this.prepMinutes = prepMinutes;
    }

    public boolean isShareable() {
        return shareable;
    }

    public void setShareable(boolean shareable) {
        this.shareable = shareable;
    }

    public boolean isFavorite() {
        return favorite;
    }

    public void setFavorite(boolean favorite) {
        this.favorite = favorite;
    }

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
}
